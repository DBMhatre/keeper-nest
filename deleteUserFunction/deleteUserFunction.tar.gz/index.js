import { Client, Databases, Users } from "node-appwrite";

export default async ({ req, res, log }) => {
  try {
    // Parse incoming request body safely
    const payload = req.body ? JSON.parse(req.body) : {};
    const { userId, documentId } = payload;

    if (!userId || !documentId) {
      return res.json({
        success: false,
        message: "userId and documentId are required",
      });
    }

    // Initialize Appwrite client with env vars
    const client = new Client()
      .setEndpoint(process.env.APPWRITE_ENDPOINT)
      .setProject(process.env.APPWRITE_PROJECT_ID)
      .setKey(process.env.APPWRITE_API_KEY);

    const users = new Users(client);
    const databases = new Databases(client);

    // Delete from Authentication
    await users.delete(userId);

    // Delete from Database
    await databases.deleteDocument(
      "user_info",
      "user_info",
      documentId
    );

    return res.json({
      success: true,
      message: `Employee deleted successfully.`,
    });

  } catch (error) {
    log(error);
    return res.json({
      success: false,
      message: "Something went wrong.",
      error: error.message,
    });
  }
};
